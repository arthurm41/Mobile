import 'package:flutter/material.dart';
import '../models/local.dart';

class LocalCard extends StatelessWidget {
  final Local local;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const LocalCard({
    super.key,
    required this.local,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                child: Icon(_iconeCategoria(local.categoria)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      local.nome,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text('${local.categoria} • ${local.cidade}'),
                    const SizedBox(height: 5),
                    Row(
                      children: [
                        const Icon(Icons.star, size: 17, color: Colors.amber),
                        Text(' ${local.avaliacao.toStringAsFixed(1)}'),
                        const SizedBox(width: 12),
                        const Icon(Icons.near_me, size: 16),
                        Text(' ${local.distancia.toStringAsFixed(1)} km'),
                      ],
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (valor) {
                  if (valor == 'editar') onEdit();
                  if (valor == 'excluir') onDelete();
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(
                    value: 'editar',
                    child: ListTile(
                      leading: Icon(Icons.edit),
                      title: Text('Editar'),
                    ),
                  ),
                  PopupMenuItem(
                    value: 'excluir',
                    child: ListTile(
                      leading: Icon(Icons.delete),
                      title: Text('Excluir'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _iconeCategoria(String categoria) {
    switch (categoria) {
      case 'Academia':
        return Icons.fitness_center;
      case 'Restaurante':
        return Icons.restaurant;
      case 'Farmácia':
        return Icons.local_pharmacy;
      case 'Mercado':
        return Icons.shopping_cart;
      case 'Escola':
        return Icons.school;
      case 'Oficina':
        return Icons.build;
      default:
        return Icons.place;
    }
  }
}
