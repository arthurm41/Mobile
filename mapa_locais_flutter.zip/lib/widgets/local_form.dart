import 'package:flutter/material.dart';
import '../models/local.dart';

class LocalForm extends StatefulWidget {
  final Local? local;

  const LocalForm({super.key, this.local});

  @override
  State<LocalForm> createState() => _LocalFormState();
}

class _LocalFormState extends State<LocalForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController nomeController;
  late final TextEditingController horarioController;
  late final TextEditingController avaliacaoController;
  late final TextEditingController distanciaController;
  late final TextEditingController descricaoController;

  final cidades = ['São Paulo', 'Campinas', 'Jundiaí'];
  final categorias = [
    'Academia',
    'Restaurante',
    'Farmácia',
    'Mercado',
    'Escola',
    'Oficina',
  ];

  late String cidadeSelecionada;
  late String categoriaSelecionada;

  @override
  void initState() {
    super.initState();
    final local = widget.local;

    nomeController = TextEditingController(text: local?.nome ?? '');
    horarioController = TextEditingController(text: local?.horario ?? '');
    avaliacaoController =
        TextEditingController(text: local?.avaliacao.toString() ?? '4.5');
    distanciaController =
        TextEditingController(text: local?.distancia.toString() ?? '1.0');
    descricaoController =
        TextEditingController(text: local?.descricao ?? '');

    cidadeSelecionada =
        cidades.contains(local?.cidade) ? local!.cidade : cidades.first;

    categoriaSelecionada = categorias.contains(local?.categoria)
        ? local!.categoria
        : categorias.first;
  }

  @override
  void dispose() {
    nomeController.dispose();
    horarioController.dispose();
    avaliacaoController.dispose();
    distanciaController.dispose();
    descricaoController.dispose();
    super.dispose();
  }

  String? obrigatorio(String? valor) {
    if (valor == null || valor.trim().isEmpty) {
      return 'Preencha este campo';
    }
    return null;
  }

  void salvar() {
    if (!_formKey.currentState!.validate()) return;

    final local = Local(
      id: widget.local?.id ?? '',
      nome: nomeController.text.trim(),
      categoria: categoriaSelecionada,
      cidade: cidadeSelecionada,
      avaliacao: double.tryParse(avaliacaoController.text.replaceAll(',', '.')) ?? 0,
      distancia: double.tryParse(distanciaController.text.replaceAll(',', '.')) ?? 0,
      horario: horarioController.text.trim(),
      descricao: descricaoController.text.trim(),
      favorito: widget.local?.favorito ?? false,
    );

    Navigator.pop(context, local);
  }

  @override
  Widget build(BuildContext context) {
    final editando = widget.local != null;

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                editando ? 'Editar local' : 'Cadastrar local',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: nomeController,
                validator: obrigatorio,
                decoration: const InputDecoration(
                  labelText: 'Nome',
                  prefixIcon: Icon(Icons.place),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: categoriaSelecionada,
                decoration: const InputDecoration(
                  labelText: 'Categoria',
                  border: OutlineInputBorder(),
                ),
                items: categorias
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setState(() => categoriaSelecionada = v!),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: cidadeSelecionada,
                decoration: const InputDecoration(
                  labelText: 'Cidade',
                  border: OutlineInputBorder(),
                ),
                items: cidades
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setState(() => cidadeSelecionada = v!),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: horarioController,
                validator: obrigatorio,
                decoration: const InputDecoration(
                  labelText: 'Horário',
                  hintText: '08:00 - 18:00',
                  prefixIcon: Icon(Icons.schedule),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: avaliacaoController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Avaliação',
                        prefixIcon: Icon(Icons.star),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: distanciaController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Distância (km)',
                        prefixIcon: Icon(Icons.near_me),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: descricaoController,
                maxLines: 3,
                validator: obrigatorio,
                decoration: const InputDecoration(
                  labelText: 'Descrição',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: salvar,
                  icon: const Icon(Icons.save),
                  label: Text(editando ? 'Salvar alterações' : 'Cadastrar'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
