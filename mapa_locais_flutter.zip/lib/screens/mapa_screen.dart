import 'package:flutter/material.dart';
import 'resultados_screen.dart';

class MapaScreen extends StatefulWidget {
  const MapaScreen({super.key});

  @override
  State<MapaScreen> createState() => _MapaScreenState();
}

class _MapaScreenState extends State<MapaScreen> {
  String cidade = 'São Paulo';
  final pesquisaController = TextEditingController();

  final cidades = ['São Paulo', 'Campinas', 'Jundiaí'];

  @override
  void dispose() {
    pesquisaController.dispose();
    super.dispose();
  }

  void abrirResultados() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultadosScreen(
          cidadeInicial: cidade,
          pesquisaInicial: pesquisaController.text,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mapa de Locais'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Column(
              children: [
                DropdownButtonFormField<String>(
                  value: cidade,
                  decoration: const InputDecoration(
                    labelText: 'Cidade',
                    prefixIcon: Icon(Icons.location_city),
                    border: OutlineInputBorder(),
                  ),
                  items: cidades
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (valor) {
                    if (valor != null) setState(() => cidade = valor);
                  },
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: pesquisaController,
                  onSubmitted: (_) => abrirResultados(),
                  decoration: InputDecoration(
                    hintText: 'O que você procura?',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: IconButton(
                      onPressed: abrirResultados,
                      icon: const Icon(Icons.arrow_forward),
                    ),
                    border: const OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black12),
                color: const Color(0xFFE7EEF5),
              ),
              child: Stack(
                children: [
                  const Center(
                    child: Icon(
                      Icons.map,
                      size: 130,
                      color: Colors.black12,
                    ),
                  ),
                  _marcador(0.20, 0.25, 'Academia'),
                  _marcador(0.62, 0.18, 'Mercado'),
                  _marcador(0.40, 0.46, 'Farmácia'),
                  _marcador(0.76, 0.55, 'Restaurante'),
                  _marcador(0.22, 0.72, 'Escola'),
                  _marcador(0.66, 0.80, 'Oficina'),
                  Positioned(
                    left: 16,
                    bottom: 16,
                    child: Chip(
                      avatar: const Icon(Icons.location_on, size: 18),
                      label: Text(cidade),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: abrirResultados,
                icon: const Icon(Icons.list),
                label: const Text('Ver resultados'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _marcador(double x, double y, String nome) {
    return Positioned(
      left: MediaQuery.of(context).size.width * x,
      top: MediaQuery.of(context).size.height * y * 0.65,
      child: Tooltip(
        message: nome,
        child: const Icon(Icons.location_on, size: 38),
      ),
    );
  }
}
