import 'package:flutter/material.dart';

import '../models/local.dart';
import '../services/local_service.dart';

class DetalhesScreen extends StatefulWidget {
  final Local local;

  const DetalhesScreen({super.key, required this.local});

  @override
  State<DetalhesScreen> createState() => _DetalhesScreenState();
}

class _DetalhesScreenState extends State<DetalhesScreen> {
  final service = LocalService();
  late bool favorito;

  @override
  void initState() {
    super.initState();
    favorito = widget.local.favorito;
  }

  Future<void> alternarFavorito() async {
    final novoValor = !favorito;

    setState(() => favorito = novoValor);

    try {
      await service.alterarFavorito(widget.local.id, novoValor);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              novoValor
                  ? 'Local adicionado aos favoritos.'
                  : 'Local removido dos favoritos.',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => favorito = !novoValor);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Erro ao alterar favorito.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final local = widget.local;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalhes do local'),
        actions: [
          IconButton(
            onPressed: alternarFavorito,
            icon: Icon(
              favorito ? Icons.favorite : Icons.favorite_border,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 210,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.blue.withValues(alpha: 0.10),
              ),
              child: const Icon(
                Icons.storefront,
                size: 100,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              local.nome,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 8),
            Chip(
              avatar: const Icon(Icons.category, size: 18),
              label: Text(local.categoria),
            ),
            const SizedBox(height: 14),
            _info(Icons.location_city, 'Cidade', local.cidade),
            _info(
              Icons.star,
              'Avaliação',
              local.avaliacao.toStringAsFixed(1),
            ),
            _info(
              Icons.near_me,
              'Distância',
              '${local.distancia.toStringAsFixed(1)} km',
            ),
            _info(Icons.schedule, 'Horário', local.horario),
            const SizedBox(height: 16),
            Text(
              'Descrição',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 6),
            Text(
              local.descricao,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Representação do local no mapa.'),
                    ),
                  );
                },
                icon: const Icon(Icons.map),
                label: const Text('Ver no mapa'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _info(IconData icone, String titulo, String valor) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icone, size: 22),
          const SizedBox(width: 12),
          Text(
            '$titulo: ',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          Expanded(child: Text(valor)),
        ],
      ),
    );
  }
}
