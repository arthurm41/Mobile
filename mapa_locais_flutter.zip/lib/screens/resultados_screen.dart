import 'package:flutter/material.dart';

import '../models/local.dart';
import '../services/local_service.dart';
import '../widgets/local_card.dart';
import '../widgets/local_form.dart';
import 'detalhes_screen.dart';

class ResultadosScreen extends StatefulWidget {
  final String cidadeInicial;
  final String pesquisaInicial;

  const ResultadosScreen({
    super.key,
    this.cidadeInicial = 'Todas',
    this.pesquisaInicial = '',
  });

  @override
  State<ResultadosScreen> createState() => _ResultadosScreenState();
}

class _ResultadosScreenState extends State<ResultadosScreen> {
  final service = LocalService();
  late final TextEditingController pesquisaController;

  late String cidade;
  String categoria = 'Todos';
  bool somenteFavoritos = false;

  final categorias = [
    'Todos',
    'Academia',
    'Restaurante',
    'Farmácia',
    'Mercado',
    'Escola',
    'Oficina',
  ];

  @override
  void initState() {
    super.initState();
    cidade = widget.cidadeInicial;
    pesquisaController =
        TextEditingController(text: widget.pesquisaInicial);
  }

  @override
  void dispose() {
    pesquisaController.dispose();
    super.dispose();
  }

  List<Local> filtrar(List<Local> locais) {
    final texto = pesquisaController.text.trim().toLowerCase();

    return locais.where((local) {
      final cidadeOk = cidade == 'Todas' || local.cidade == cidade;
      final categoriaOk =
          categoria == 'Todos' || local.categoria == categoria;
      final textoOk = texto.isEmpty ||
          local.nome.toLowerCase().contains(texto) ||
          local.categoria.toLowerCase().contains(texto);
      final favoritoOk = !somenteFavoritos || local.favorito;

      return cidadeOk && categoriaOk && textoOk && favoritoOk;
    }).toList();
  }

  Future<void> cadastrar() async {
    final local = await showModalBottomSheet<Local>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const LocalForm(),
    );

    if (local == null) return;

    try {
      await service.adicionar(local);
      if (mounted) {
        _mensagem('Local cadastrado com sucesso.');
      }
    } catch (e) {
      if (mounted) _mensagem('Erro ao cadastrar local.', erro: true);
    }
  }

  Future<void> editar(Local local) async {
    final atualizado = await showModalBottomSheet<Local>(
      context: context,
      isScrollControlled: true,
      builder: (_) => LocalForm(local: local),
    );

    if (atualizado == null) return;

    try {
      await service.atualizar(atualizado);
      if (mounted) _mensagem('Local atualizado com sucesso.');
    } catch (e) {
      if (mounted) _mensagem('Erro ao atualizar local.', erro: true);
    }
  }

  Future<void> excluir(Local local) async {
    final confirmou = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir local?'),
        content: Text(
          'Tem certeza que deseja excluir "${local.nome}"? Esta ação não poderá ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmou != true) return;

    try {
      await service.excluir(local.id);
      if (mounted) _mensagem('Local excluído com sucesso.');
    } catch (e) {
      if (mounted) _mensagem('Erro ao excluir local.', erro: true);
    }
  }

  void abrirDetalhes(Local local) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DetalhesScreen(local: local),
      ),
    );
  }

  void _mensagem(String mensagem, {bool erro = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensagem),
        backgroundColor: erro ? Colors.red : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Resultados'),
        actions: [
          IconButton(
            tooltip: 'Cadastrar',
            onPressed: cadastrar,
            icon: const Icon(Icons.add_business),
          ),
        ],
      ),
      body: StreamBuilder<List<Local>>(
        stream: service.listarLocais(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(
              child: Text('Erro ao carregar os locais do Firestore.'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final locais = filtrar(snapshot.data ?? []);

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    TextField(
                      controller: pesquisaController,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        hintText: 'Pesquisar por nome ou categoria',
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: cidade,
                            decoration: const InputDecoration(
                              labelText: 'Cidade',
                              border: OutlineInputBorder(),
                            ),
                            items: ['Todas', 'São Paulo', 'Campinas', 'Jundiaí']
                                .map(
                                  (c) => DropdownMenuItem(
                                    value: c,
                                    child: Text(c),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) {
                              setState(() => cidade = v!);
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: categoria,
                            decoration: const InputDecoration(
                              labelText: 'Categoria',
                              border: OutlineInputBorder(),
                            ),
                            items: categorias
                                .map(
                                  (c) => DropdownMenuItem(
                                    value: c,
                                    child: Text(c),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) {
                              setState(() => categoria = v!);
                            },
                          ),
                        ),
                      ],
                    ),
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Mostrar somente favoritos'),
                      value: somenteFavoritos,
                      onChanged: (v) {
                        setState(() => somenteFavoritos = v ?? false);
                      },
                      controlAffinity: ListTileControlAffinity.leading,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: locais.isEmpty
                    ? const Center(
                        child: Text('Nenhum local encontrado.'),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: locais.length,
                        itemBuilder: (_, index) {
                          final local = locais[index];
                          return LocalCard(
                            local: local,
                            onTap: () => abrirDetalhes(local),
                            onEdit: () => editar(local),
                            onDelete: () => excluir(local),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: cadastrar,
        icon: const Icon(Icons.add),
        label: const Text('Cadastrar'),
      ),
    );
  }
}
