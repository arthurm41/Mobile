# Mapa de Locais - Flutter + Firebase

Projeto desenvolvido conforme a avaliação de Desenvolvimento de Aplicação Mobile.

## Funcionalidades

- Seleção de São Paulo, Campinas e Jundiaí
- Tela principal com representação de mapa e marcadores
- Pesquisa por nome ou categoria
- Filtro por cidade
- Filtro por categoria
- Filtro de favoritos
- Cadastro de locais
- Edição de locais
- Exclusão com confirmação
- Tela de detalhes
- Favoritos salvos no Firestore
- Mensagens de sucesso e erro

## Configuração

1. Crie o projeto:
   flutter create mapa_locais

2. Substitua a pasta `lib` e o `pubspec.yaml` pelos arquivos deste projeto.

3. Configure o Firebase:
   firebase login
   dart pub global activate flutterfire_cli
   flutterfire configure

4. Instale os pacotes:
   flutter pub get

5. No Firebase Console, crie o Cloud Firestore.

6. Crie a coleção `locais`.

7. Rode:
   flutter run

## Estrutura do Firestore

Coleção:
locais

Campos:
- nome: String
- categoria: String
- cidade: String
- avaliacao: Number
- distancia: Number
- horario: String
- descricao: String
- favorito: Boolean

## Importante

O arquivo `lib/firebase_options.dart` NÃO deve ser criado manualmente.
Ele é gerado pelo comando:

flutterfire configure

Não coloque credenciais reais no código manualmente.
